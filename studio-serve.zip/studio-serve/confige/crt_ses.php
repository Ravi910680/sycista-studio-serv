<?php
session_start();




$_SESSION['email']=$_GET['email'];
$_SESSION['id']=$_GET['id'];


header("Location: ".$_GET['url_red']);

?>