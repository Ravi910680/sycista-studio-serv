<?php
  

header('Access-Control-Allow-Origin: *');


require("../confige/imagedir.conf.php");

require("../confige/imagesave.conf.php");






$fold_name=$_GET['fold_old_name'];



$flg_suc=0;

$str_for_chk_crw="select * from imagedirname where dir='$fold_name' and extra='0'";
$res_of_check=$imagedir->query($str_for_chk_crw);

$rows_count=$res_of_check->num_rows;


if($rows_count){

$select_img_file="select * from `$fold_name`";

$all_file_name = $imagesave->query($select_img_file);


if ($all_file_name->num_rows > 0) {
    // output data of each row
    while($row = $all_file_name->fetch_assoc()) {
        
$rename_stat=unlink("./images/".$row['image']);


    }



$drop_tbls="drop table `$fold_name`";




if($imagesave->query($drop_tbls)==true){

	$delet_dir_name="delete from imagedirname where dir='$fold_name'";

	if($imagedir->query($delet_dir_name)==true){

		$flg_suc=1;
	}else{
		$flg_suc=0;
	}

}else{
  $flg_suc=0;
}




} else {
    

$drop_tbls="drop table `$fold_name`";




if($imagesave->query($drop_tbls)==true){

$delet_dir_name="delete from imagedirname where dir='$fold_name'";
        
        if($imagedir->query($delet_dir_name)==true){

                $flg_suc=1;
        }else{
                $flg_suc=0;
        }


}else{
  $flg_suc=0;
}




}


}


echo $flg_suc;


?>
