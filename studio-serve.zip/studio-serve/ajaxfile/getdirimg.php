<?php

require("../confige/imagesave.conf.php");


if(isset($_POST['dir_name'])){
$dir_name=$_POST['dir_name'];
$img_name_array=array();
$select_img_name = "SELECT * FROM `$dir_name`";

$geted_img=$imagesave->query($select_img_name);
if ($geted_img->num_rows > 0) {
    // output data of each row
    while($row = $geted_img->fetch_assoc()) {
      
        array_push($img_name_array,$row['image']);
       

    }

    $respons_img_name = json_encode($img_name_array);
    echo $respons_img_name;
} else {
    echo "0";
}


}
?>
