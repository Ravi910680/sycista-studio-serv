<?php

session_start();
require './vendor/autoload.php';
use Abraham\TwitterOAuth\TwitterOAuth;


$jsn_dec_data=json_decode($_POST['post_data']);


$acc_tok=$_POST['acc_tok'];
$acc_tok_sec=$_POST['acc_tok_sec'];



$consumerkey = "Ez4QEjTHyepCBVZliPWZoWWnn";
$consumersecret = "Tfu97VINIz7V1VyOZ8KtXCnaXVZ4Q7K22cVfi74yT31Xj6FGq9";

$post_id=array();

$twitteroauth = new TwitterOAuth($consumerkey, $consumersecret,$acc_tok,$acc_tok_sec);

if(strlen( $jsn_dec_data->img)!=0){

$arr_of_jsn_img=explode(",", $jsn_dec_data->img);

$cnt_img=count($arr_of_jsn_img);



for ($i=0; $i <$cnt_img-1 ; $i++) { 


$media1 = $twitteroauth->upload('media/upload', ['media' => '../../../studio/ajaxfile/images/'.$arr_of_jsn_img[$i]]);



array_push($post_id,$media1->media_id_string );

}


}





$parameters = [
    'status' => $jsn_dec_data->text." ".$jsn_dec_data->url,
    'media_ids' => implode(',', $post_id)
];


$mediaOBJ = $twitteroauth->post('statuses/update', $parameters);

if(isset($mediaOBJ->id)){


echo 0;

}else{
	echo 1;
}





?>
