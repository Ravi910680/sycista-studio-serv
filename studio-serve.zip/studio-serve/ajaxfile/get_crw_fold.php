<?php

session_start();



require("../confige/imagedir.conf.php");



$id=$_SESSION['id'];
  $select_dir="SELECT * FROM imagedirname WHERE id='$id' AND extra='1'";
  $slected_dir = $imagedir->query($select_dir);
  $rows_count=$slected_dir->num_rows;

  if($rows_count==0){

echo 0;

  }else{
  while($row = $slected_dir->fetch_assoc()){
      $dbdata[]=$row;
  }
  $datavar=json_encode($dbdata);

echo $datavar;

  }
?>
