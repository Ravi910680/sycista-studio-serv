<?php
session_start();

require("../confige/imagedir.conf.php");

require("../confige/imagesave.conf.php");

$id=$_SESSION["id"];

if(strlen($_POST["dir_name_up"])>0){
    $dir_name= $_POST["dir_name_up"];
}else{
    $dir_name=$id."^".base64_encode("undefine");

}


$image_dir_select="SELECT * FROM imagedirname WHERE dir='$dir_name'";

$result = $imagedir->query($image_dir_select);
$row = $result->fetch_assoc();


$targetFilePath="images/";
$count_saved=$row['count'];
$all_count=$row["allcount"];
foreach($_FILES['pic']['name'] as $key=>$val){
        $image_name = $_FILES['pic']['name'][$key];
        $tmp_name   = $_FILES['pic']['tmp_name'][$key];
        $size       = $_FILES['pic']['size'][$key];
        $type       = $_FILES['pic']['type'][$key];
        $error      = $_FILES['pic']['error'][$key];

$type_ext=explode("/",$type);
$image_db_name=$dir_name."^".$all_count.".".$type_ext[1];
         if(move_uploaded_file($_FILES['pic']['tmp_name'][$key],$targetFilePath.$image_db_name)){

             $image_info = getimagesize($targetFilePath.$image_db_name);
$width=$image_info[0];
$height=$image_info[1];
                $insert_img_data = "INSERT INTO `".$dir_name."`  VALUES ('$image_db_name', '$width', '$height','$size','$image_name')";
                if($imagesave->query($insert_img_data)==TRUE){

$all_count=$all_count+1;
$count_saved=$count_saved+1;


                }

            }
        

}



$count_update = "UPDATE imagedirname SET count='$count_saved',allcount='$all_count' WHERE dir='$dir_name'";

if($imagedir->query($count_update)=='true'){
	echo $image_db_name;
}else{



echo 0;
}



?>
