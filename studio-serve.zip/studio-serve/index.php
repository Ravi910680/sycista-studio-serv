<?php
session_start();

    
if(isset($_SESSION["email"])){
require("./confige/account.conf.php");


$id=$_SESSION["id"];

$mail=$_SESSION['email'];

$sql = "SELECT id FROM userinfo WHERE email='$mail' and varflag='1'";


$result=$conn->query($sql);
$count = mysqli_num_rows($result);

if($count!=1)
{

header("location:https://account.sycista.com/verify/");

}

}else{


 header("location:https://account.sycista.com/login/");

}

?>
<!DOCTYPE html>
<html lang="en">
<style>

</style>
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
 <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script src="https://cdn.scaleflex.it/plugins/filerobot-image-editor/3/filerobot-image-editor.min.js"/></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">

<!-- Latest compiled JavaScript -->

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet">

 
<style>

.tablediv{
    padding:10%;
}




.cont-img-data {

margin:20px;
  position: relative;
  width: 50%;
  max-width: 300px;
}

.image-data-kl {
  display: block;
  width: 100%;
  height: auto;
}

button:hover{

cursor: pointer !important;

}

.overlay-2 {
  position: absolute; 
  bottom: 0; 
 
  color: #f1f1f1; 
  height:100%;
  width: 100%;
  transition: .5s ease;
  opacity:0;
  color: white;
  font-size: 20px;
  padding: 20px;
  text-align: center;
}

.cont-img-data:hover .overlay-2 {
  opacity:1;
}
.down_con{
  font-size: 13px;
opacity:1 !important;
float:right;

background:white;
padding:10px;
color:black;
border-radius:5px;
}



.ip-src{
  
  width: 100%;
    height: 50px;
    padding: 10px;
    border-right: 0px;
    border: none;
    border-radius: 1000px 0px 0px 1000px;
}

.src-btn{
  
  height: 50px;padding: 10px;border-left: 0px;
}









.fold_con{


border-radius:5px;
width: 150px;
    height: 150px;
    transition:0.2s;
    margin: 10px;
    text-align: center !important;


}

.fold_con:hover{
background: #f0f8ff !important;

}



.fold_name{

overflow:scroll;
padding-top: 10px;
    padding-bottom: 10px;
    height: 50px;
    width: 100%;
    font-weight: 900;
    color: #096263e8;
}


.getimg:hover{
    cursor:pointer;
    background:#f2f2f2;
    color:red;
}
.sc-kEYyzF{
    text-align:right;
    padding:20px;
    font-size:15px;
}





.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}



.not-fd-data{


height:fit-content;
margin:auto;
  text-align: center;
}
.savelink:hover{
color:blue;
}
.delet_btn:hover{
    cursor:pointer;
}

.bottom-btn {
    position: relative;
    display: inline-block;
    padding: 5px 16px;
    font-size: 13px;
    font-weight: 500;
    line-height: 20px;
    white-space: nowrap;
    vertical-align: middle;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 1px solid;
    border-radius: 6px;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    height: 5vh;

  }
input.ip-src:focus {
    outline: none;
}



button{
    border-style:none ;
}
.delet_btn{
    border: none;
    
    color: white;
    height: 40px;
    
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 1px;
}
.getimg {
    text-align: left;
    padding: 5px;
    color: black;
    font-size: 14px;
    padding-right: 20px;
    padding-left: 20px;

  }

.getimg a{
    
    color:#1a73e8;
    
    font-weight:400;
    
}
.img-con {
    margin:20px;position: relative;
  position: relative;
background:#82828617; 
border-radius:7px; 
height: fit-content;
}
.input-search:focus{
    outline:none;

}






.modal-dialog.modal-dialog-centered {
    min-width: 70%;
  }






.imag-cls{
  
    border-radius:7px;
    display: block;
  height:175px;
  
}

.lds-ripple {
  display: inline-block;
  position: relative;
  width: 80px;
  height: 80px;
}
.lds-ripple div {
  position: absolute;
  border: 4px solid black;
  opacity: 1;
  border-radius: 50%;
  animation: lds-ripple 1s cubic-bezier(0, 0.2, 0.8, 1) infinite;
}
.lds-ripple div:nth-child(2) {
  animation-delay: -0.5s;
}
@keyframes lds-ripple {
  0% {
    top: 36px;
    left: 36px;
    width: 0;
    height: 0;
    opacity: 1;
  }
  100% {
    top: 0px;
    left: 0px;
    width: 72px;
    height: 72px;
    opacity: 0;
  }
}






.lds-color div{

border: 2px solid #4a154bd9 !important;border-color: #4a154bd9 transparent transparent transparent !important;

}


.imag-cls:hover{
    
    cursor:pointer;
    

}






.hidden_ele_of_cp{
display:none;
}


.overlay:hover{
    cursor:pointer;
}
.overlay {
    
    border-radius:7px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 100%;
  opacity: 0;
  transition: .5s ease;
  background-color: #f2f2f2;
}

.text {
  color: white;
  font-size: 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  text-align: center;
  
}
.list-log:hover{
  cursor: pointer;
    color: #190a38de !important;
    font-weight: 900;
    padding-left: 20px;


background: #1854560d;
    border-radius: 0px 1000px 1000px 0px;

}
.list-log-act{
cursor: pointer;
background: #497faf45;
    border-radius: 0px 1000px 1000px 0px;

 width: 100%;
    color: black;
    padding: 10px;
    
    font-size: 15px;
   transition:0.2s; 
    color:#260b5ff7 !important;
    font-weight: 900;
    padding-left: 20px;
}
.list-log{




    width: 100%;
    color: black;
    padding: 10px;
    font-weight: 600;
    font-size: 13px;
    transition: 0.5s;










}
button:focus{
    outline:none;
}
.btn-my:hover{
    outline:2px solid;

}
#add_folder_con:hover{
    cursor:pointer;
    background:#e8f0fe;
}
.btn-dp-fold:hover{
cursor:pointer;
    background:#e8f0fe;
border-radius:5px;

}

a{
    font-weight:900;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
div{
    c
}


.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
.nav-link:hover{
    cursor:pointer;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.dropdown-menu{
    border-radius:0px;
    box-shadow:none;
    
    border:1px solid #dedddc;
   
}

.fal {
    width: 40px;
    font-family: 'Font Awesome 5 Pro';
    font-weight: 300;
    text-align: center;
  }

  .btn-without-clr{
    background: no-repeat;
    color: #4a154bd9;
  }


  a.savelink {
    color: white;
    padding: 10px;
    background: green;
    border-radius: 5px;
  }
a.savelink:hover{
  cursor: pointer;
  color: white !important;
}


.modal {
    z-index: 100000000;

    }

    div#err_mdl_con {
    max-height: 50px;
    padding: 10px;
   }

   .mdl_stat_suc{
     color: green;
    border: 2px solid green;
    padding: 10px;
    border-radius: 5px;
   }



.btn-round-act:hover{
background: #f2f2f2;

}




   .btn-round-act {
    background: white;
    height: 50px;
    width: 50px;
    padding: auto;
    border-radius: 50%;
    color: black;
    margin: 0px 10px;
    transition: .2s;

  }


.btn-con-for-opt-img-std {
    display: none;

  }

  .fad{
width: 40px;
    
    color: green;
    font-weight: 300;
    text-align: center;
  }



  button.btn_hover_clr {
    
    background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    font-size: 13px;
    font-weight: 500;
    float: right;
    color: #471f48f0;

  }

  button.btn_hover_clr:hover {
    background: #b284b336;
    cursor: pointer;

  }


.dropdown-caret {
    display: inline-block;
    width: 0;
    height: 0;
    vertical-align: middle;
    content: "";
    border-top-style: solid;
    border-top-width: 4px;
    border-right: 4px solid transparent;
    border-bottom: 0 solid transparent;
    border-left: 4px solid transparent;

  }

.back_wt_con{
  color: #24292e;
  background-color: #fafbfc;
  border-color: #1b1f2326;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;

    }

nav.navbar.navbar-expand-lg.navbar-light{
  position: relative !important;
}








.vert-cent-div {
  width: min-content;
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.info-err-img{
  height: 200px;
}

.dt-knw-abt-camp{
  font-weight: 600;
  font-size: 13px;
  padding-top: 10px;
  text-align: center;
}

.txt-hlght-in-para{
  color: green;
}




.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b5;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}

.hover-red-del-btn{
color: #d73a49;

}

.hover-red-del-btn:hover{

background: #d73a49;
color: white;
transition:.2s;

}


.tw-rw-mdl-con::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.tw-rw-mdl-con {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}




</style>



<style>

.myButton {
    padding: .2em 1em;
    font-size: 1em;
}

#copied_not {
    

width: 300px;
    position: absolute;
    will-change: transform;
    display: none;
    top: 0;
    right: 10px;
    padding: 20px;
    border-radius: 5px;
    background: rgba(105, 106, 109, 0.94);
    color: white;
    border: 1px solid rgba(0, 0, 255, 0.96);
    font-weight: 800;
    font-size: 20px;




}

.dir_cont{
  padding-top: 8px;

max-height:250px;
overflow-y:scroll;
}














button.btn-theme-dsg {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;


  }

  .modal{
    z-index: 10000000000;
  }


  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}



.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
  position: relative;
  display: flex;
}
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}






</style>




<style>

.show_edt_btn .dropdown{

    color: #104b7b;
    border-radius: 4px;
}

.dr_sec_dw{
border: none;
    color:#104b7b;
    height: 40px;
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 1px;

}



/* Tooltip text */
.tooltip2 .tooltiptext {
  visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 40px;
}

.tooltip2:hover .tooltiptext {
  visibility: visible;
}


svg.svg-ico-of-dt {
    margin-right: 10px;

  }


  button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
  }


.main-div-sel-img {
    height: 156px;
    overflow-y: scroll;

  }

  label {
    color: #4a154bd9;
    font-weight: 500;
    padding: 4px 0px;

  }

  .midd-sel-img {
    padding: 40px;
    border: 1px dashed;
    width: fit-content;
    padding: 40px;
    height: 100px;
    margin: 20px;

  }

  i.fal.fa-layer-plus {
    color: #4a154bd9;
  }

  a.nav-link.lnk-of-foot-nav {
    font-size: 13px;
    color: #4a154b !important;

  }

</style>


<style>

.res_error{
padding-top: 20px;
    color: red;
    font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
}

.modal-header{
height: 60px; */
}
.modal-body{
height: 540px;
    overflow: scroll;
}

.btn-con-del-camp {
    width: 100%;
    }

.head-line-of-mdl h4 {
    color: black;
  }

  .modal-2 .content-wrapper .content p {
    font-size: 0.875rem;
    line-height: 1.75;
  }

  .modal-2 .content-wrapper .content {
    position: relative;
    display: flex;
    text-align: center;
    color: #504b4b;
  }



img.img-pre-tg-img {
    height: 100px;
    width: 100px;
margin: 20px;
}

i.fal.fa-layer-plus {
    color: #4a154bd9;

}

.img-pre-tg-img{

cursor:pointer;
}

</style>





<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  
<script>
 var op=[];
 var count_sel_img=0;
</script>
 
  <!-- CSS Files -->
 
</head>
<div id="c"></div>
<body class="" style="overflow:hidden;">




<?php require("./confige/header.php");?>




<div class="vert-cent-div err-menu-cls-dsg" id="err_msg_dt_trg" style="display: none;">

 
 <span id="con-of-err-msg"></span>

<span class="cls-err-menu" id="cncl-err-msg">

<i class="fal fa-times-circle" style="
    padding: 6px;
"></i>

</span>


</div>


 
<div id="loader" style="display:none" ></div>


<div id='main-loader-containre'>

<div class="main-content" style="top:0vh;">

<div class="container edit-opt" style="max-width:90%;">

<div class='all_head_con' style='padding:8vh 0vh;height:21vh;'>
<div class="row" style="margin-left:0px;margin-right:0px;height:5vh;">
<div style="width:50%;">


<div class="row" style="margin-left:0px;margin-right:0px">
<div class="dropdown">
<button class="bottom-btn back_wt_con" id="get-dir" data-toggle="dropdown">

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M2 19C2 20.6569 3.34315 22 5 22H19C20.6569 22 22 20.6569 22 19V5C22 3.34315 20.6569 2 19 2H5C3.34315 2 2 3.34315 2 5V19ZM20 19C20 19.5523 19.5523 20 19 20H5C4.44772 20 4 19.5523 4 19V5C4 4.44772 4.44772 4 5 4H10V12.0111L12.395 12.0112L14.0001 9.86419L15.6051 12.0112H18.0001L18 4H19C19.5523 4 20 4.44772 20 5V19ZM16 4H12V9.33585L14.0001 6.66046L16 9.33571V4Z" fill="currentColor"></path></svg>


<span style="padding-left:10px;">Folder</span> <span class="dropdown-caret"></span></button>
  
  <div class="dropdown-menu" style="width:300px;padding-top:0px;border-radius:5px;">
  
<div class="dir_cont" id="dir_data"><div id="19^bmV3aWRy" class="getimg" data-flg-ext="0"><a href="#"><img src="https://res.cloudinary.com/heptera/image/upload/v1604420625/icon-svg/align-left_nwl9zn.svg" height="20"><span style="padding-left:10px;">newidr</span></a><span class="" style="color:black;padding-left:20px;">0 files</span></div></div>

  </div>

</div><!-----drop-->



<button class="bottom-btn back_wt_con" data-modal-trigger="crt-new-dir-mdl" id="add_folder_con"  style="margin-left:20px;">

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 14.5V16.5H13V14.5H15V12.5H13V10.5H11V12.5H9V14.5H11Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M4 1.5C2.89543 1.5 2 2.39543 2 3.5V4.5C2 4.55666 2.00236 4.61278 2.00698 4.66825C0.838141 5.07811 0 6.19118 0 7.5V19.5C0 21.1569 1.34315 22.5 3 22.5H21C22.6569 22.5 24 21.1569 24 19.5V7.5C24 5.84315 22.6569 4.5 21 4.5H11.874C11.4299 2.77477 9.86384 1.5 8 1.5H4ZM9.73244 4.5C9.38663 3.9022 8.74028 3.5 8 3.5H4V4.5H9.73244ZM3 6.5C2.44772 6.5 2 6.94772 2 7.5V19.5C2 20.0523 2.44772 20.5 3 20.5H21C21.5523 20.5 22 20.0523 22 19.5V7.5C22 6.94772 21.5523 6.5 21 6.5H3Z" fill="currentColor" /></svg>


</button>




<button class="bottom-btn back_wt_con hover-red-del-btn" id="delet_fold"  data-modal-trigger="modal-del-dir"  style="margin-left:20px;">

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M17 5V4C17 2.89543 16.1046 2 15 2H9C7.89543 2 7 2.89543 7 4V5H4C3.44772 5 3 5.44772 3 6C3 6.55228 3.44772 7 4 7H5V18C5 19.6569 6.34315 21 8 21H16C17.6569 21 19 19.6569 19 18V7H20C20.5523 7 21 6.55228 21 6C21 5.44772 20.5523 5 20 5H17ZM15 4H9V5H15V4ZM17 7H7V18C7 18.5523 7.44772 19 8 19H16C16.5523 19 17 18.5523 17 18V7Z" fill="currentColor" /><path d="M9 9H11V17H9V9Z" fill="currentColor" /><path d="M13 9H15V17H13V9Z" fill="currentColor" /></svg>


</button>



<div id="folder_open" style="width:auto;padding:8px;color:#1a73e8;font-size:15px;height:40px;padding-left:30px;" class="">undefine</div>



</div>



</div>
<div style="width:50%">
<div class="float-right">
<div class="dropdown">
<button class="bottom-btn" data-toggle="dropdown" aria-expanded="false" style="
    background: #2ea44f;
    border-color: white;
    color: white;
">


<svg width="20"  height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 14.9861C11 15.5384 11.4477 15.9861 12 15.9861C12.5523 15.9861 13 15.5384 13 14.9861V7.82831L16.2428 11.0711L17.657 9.65685L12.0001 4L6.34326 9.65685L7.75748 11.0711L11 7.82854V14.9861Z" fill="currentColor" /><path d="M4 14H6V18H18V14H20V18C20 19.1046 19.1046 20 18 20H6C4.89543 20 4 19.1046 4 18V14Z" fill="currentColor" /></svg>


<span style='padding-left:10px;'>Upload</span> <span class="dropdown-caret"></span></button>  
  <div class="dropdown-menu" style='border-radius:5px;'>
    <button class="dropdown-item  comm_up_btn " dis-target="allow" id="upload_frm_local"   data-modal-trigger="image_upload"   >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7 7C5.34315 7 4 8.34315 4 10C4 11.6569 5.34315 13 7 13C8.65685 13 10 11.6569 10 10C10 8.34315 8.65685 7 7 7ZM6 10C6 9.44772 6.44772 9 7 9C7.55228 9 8 9.44772 8 10C8 10.5523 7.55228 11 7 11C6.44772 11 6 10.5523 6 10Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M3 3C1.34315 3 0 4.34315 0 6V18C0 19.6569 1.34315 21 3 21H21C22.6569 21 24 19.6569 24 18V6C24 4.34315 22.6569 3 21 3H3ZM21 5H3C2.44772 5 2 5.44772 2 6V18C2 18.5523 2.44772 19 3 19H7.31374L14.1924 12.1214C15.364 10.9498 17.2635 10.9498 18.435 12.1214L22 15.6863V6C22 5.44772 21.5523 5 21 5ZM21 19H10.1422L15.6066 13.5356C15.9971 13.145 16.6303 13.145 17.0208 13.5356L21.907 18.4217C21.7479 18.7633 21.4016 19 21 19Z" fill="currentColor" /></svg>

<span class='padding-left:10px;'>
      Upload from Files </span></button>
    <button id='btn-open-mdl-url' data-modal-trigger="link_img_url" dis-target="allow"  class="dropdown-item  comm_up_btn "   >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14 0C16.7614 0 19 2.23858 19 5V17C19 20.866 15.866 24 12 24C8.13401 24 5 20.866 5 17V9H7V17C7 19.7614 9.23858 22 12 22C14.7614 22 17 19.7614 17 17V5C17 3.34315 15.6569 2 14 2C12.3431 2 11 3.34315 11 5V17C11 17.5523 11.4477 18 12 18C12.5523 18 13 17.5523 13 17V6H15V17C15 18.6569 13.6569 20 12 20C10.3431 20 9 18.6569 9 17V5C9 2.23858 11.2386 0 14 0Z" fill="currentColor" /></svg>

    <span class='padding-left:10px;'>  Clip From Url</span></button>
    
  </div>
</div>

</div>
</div><!-70%--->
</div>


 





<div style="height:5vh;width:50%;text-align: right;margin-left:auto;">

<div style="height:5vh;">
    <div class="btn-con-for-opt-img-std show_edt_btn" style="">
      <button class="btn-round-act edit_btn tooltip2" >

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 5C15 6.65685 13.6569 8 12 8C10.3431 8 9 6.65685 9 5C9 3.34315 10.3431 2 12 2C13.6569 2 15 3.34315 15 5Z" fill="currentColor" /><path d="M14 12C14 13.1046 13.1046 14 12 14C10.8954 14 10 13.1046 10 12C10 10.8954 10.8954 10 12 10C13.1046 10 14 10.8954 14 12Z" fill="currentColor" /><path d="M12 22C13.6569 22 15 20.6569 15 19C15 17.3431 13.6569 16 12 16C10.3431 16 9 17.3431 9 19C9 20.6569 10.3431 22 12 22Z" fill="currentColor" /><path d="M22 12C22 13.6569 20.6569 15 19 15C17.3431 15 16 13.6569 16 12C16 10.3431 17.3431 9 19 9C20.6569 9 22 10.3431 22 12Z" fill="currentColor" /><path d="M5 15C6.65685 15 8 13.6569 8 12C8 10.3431 6.65685 9 5 9C3.34315 9 2 10.3431 2 12C2 13.6569 3.34315 15 5 15Z" fill="currentColor" /></svg>


        <span class="tooltiptext">edit image</span></button>
    <button class="btn-round-act down_btn_img_dir tooltip2">

      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 5C11 4.44772 11.4477 4 12 4C12.5523 4 13 4.44772 13 5V12.1578L16.2428 8.91501L17.657 10.3292L12.0001 15.9861L6.34326 10.3292L7.75748 8.91501L11 12.1575V5Z" fill="currentColor" /><path d="M4 14H6V18H18V14H20V18C20 19.1046 19.1046 20 18 20H6C4.89543 20 4 19.1046 4 18V14Z" fill="currentColor" /></svg>


      <span class="tooltiptext">download</span></button>
    <button class="btn-round-act copy_con_all tooltip2" id='copy_link_img'>

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13 7H7V5H13V7Z" fill="currentColor" /><path d="M13 11H7V9H13V11Z" fill="currentColor" /><path d="M7 15H13V13H7V15Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M3 19V1H17V5H21V23H7V19H3ZM15 17V3H5V17H15ZM17 7V19H9V21H19V7H17Z" fill="currentColor" /></svg>
      <span class="tooltiptext">copy link</span></button>
    <button class="btn-round-act tooltip2"  id='info_img_href' href='#'  data-modal-trigger="img_info_mdl">

<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 10.9794C11 10.4271 11.4477 9.97937 12 9.97937C12.5523 9.97937 13 10.4271 13 10.9794V16.9794C13 17.5317 12.5523 17.9794 12 17.9794C11.4477 17.9794 11 17.5317 11 16.9794V10.9794Z" fill="currentColor" /><path d="M12 6.05115C11.4477 6.05115 11 6.49886 11 7.05115C11 7.60343 11.4477 8.05115 12 8.05115C12.5523 8.05115 13 7.60343 13 7.05115C13 6.49886 12.5523 6.05115 12 6.05115Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM4 12C4 16.4183 7.58172 20 12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12Z" fill="currentColor" /></svg>

      <span class="tooltiptext">info</span></button>
    
    
    
    </div>
    <div class="btn-con-for-opt-img-std delet_btn"><button id='sub_del_img' class="btn-round-act">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M17 5V4C17 2.89543 16.1046 2 15 2H9C7.89543 2 7 2.89543 7 4V5H4C3.44772 5 3 5.44772 3 6C3 6.55228 3.44772 7 4 7H5V18C5 19.6569 6.34315 21 8 21H16C17.6569 21 19 19.6569 19 18V7H20C20.5523 7 21 6.55228 21 6C21 5.44772 20.5523 5 20 5H17ZM15 4H9V5H15V4ZM17 7H7V18C7 18.5523 7.44772 19 8 19H16C16.5523 19 17 18.5523 17 18V7Z" fill="currentColor" /><path d="M9 9H11V17H9V9Z" fill="currentColor" /><path d="M13 9H15V17H13V9Z" fill="currentColor" /></svg>

    </button>
    
    
    
    </div>
    

</div>
</div>


</div>
</div>
</div>


<div class='container' style='padding-right:0px;max-width:95%;margin-right:0px;'>
<div class="row" style="">
<div class="" style="height:63vh;width:20%;border-right:1px solid #dedddc;">
<ul style="padding:0px;padding:10px;">
<li class="list-log" id='all_fold_data'>


<svg width="20" height="20" class='svg-ico-of-dt' viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7 7C5.34315 7 4 8.34315 4 10C4 11.6569 5.34315 13 7 13C8.65685 13 10 11.6569 10 10C10 8.34315 8.65685 7 7 7ZM6 10C6 9.44772 6.44772 9 7 9C7.55228 9 8 9.44772 8 10C8 10.5523 7.55228 11 7 11C6.44772 11 6 10.5523 6 10Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M3 3C1.34315 3 0 4.34315 0 6V18C0 19.6569 1.34315 21 3 21H21C22.6569 21 24 19.6569 24 18V6C24 4.34315 22.6569 3 21 3H3ZM21 5H3C2.44772 5 2 5.44772 2 6V18C2 18.5523 2.44772 19 3 19H7.31374L14.1924 12.1214C15.364 10.9498 17.2635 10.9498 18.435 12.1214L22 15.6863V6C22 5.44772 21.5523 5 21 5ZM21 19H10.1422L15.6066 13.5356C15.9971 13.145 16.6303 13.145 17.0208 13.5356L21.907 18.4217C21.7479 18.7633 21.4016 19 21 19Z" fill="currentColor" /></svg>


  <span>All</span></li>


<li class="list-log" id='customtbl_img'>

<svg width="20" height="20" class='svg-ico-of-dt' viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M2 19C2 20.6569 3.34315 22 5 22H19C20.6569 22 22 20.6569 22 19V5C22 3.34315 20.6569 2 19 2H5C3.34315 2 2 3.34315 2 5V19ZM20 19C20 19.5523 19.5523 20 19 20H5C4.44772 20 4 19.5523 4 19V5C4 4.44772 4.44772 4 5 4H10V12.0111L12.395 12.0112L14.0001 9.86419L15.6051 12.0112H18.0001L18 4H19C19.5523 4 20 4.44772 20 5V19ZM16 4H12V9.33585L14.0001 6.66046L16 9.33571V4Z" fill="currentColor" /></svg>
  <span>Custumized</span><li>
<li class="list-log" id='soc_img'>

<svg width="20" height="20" class='svg-ico-of-dt' viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 7C9.23858 7 7 9.23858 7 12C7 14.7614 9.23858 17 12 17C14.7614 17 17 14.7614 17 12C17 9.23858 14.7614 7 12 7ZM9 12C9 13.6569 10.3431 15 12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12Z" fill="currentColor" /><path d="M18 5C17.4477 5 17 5.44772 17 6C17 6.55228 17.4477 7 18 7C18.5523 7 19 6.55228 19 6C19 5.44772 18.5523 5 18 5Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M5 1C2.79086 1 1 2.79086 1 5V19C1 21.2091 2.79086 23 5 23H19C21.2091 23 23 21.2091 23 19V5C23 2.79086 21.2091 1 19 1H5ZM19 3H5C3.89543 3 3 3.89543 3 5V19C3 20.1046 3.89543 21 5 21H19C20.1046 21 21 20.1046 21 19V5C21 3.89543 20.1046 3 19 3Z" fill="currentColor" /></svg>

  <span>Social Page</span><li>
<li class="list-log" id='cld_img_get'>

<svg width="20" height="20" class='svg-ico-of-dt' viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M14.738 19.9964C14.8186 19.9988 14.8994 20 14.9806 20C19.3989 20 22.9806 16.4183 22.9806 12C22.9806 7.58172 19.3989 4 14.9806 4C12.4542 4 10.2013 5.17108 8.73522 7H7.51941C3.92956 7 1.01941 9.91015 1.01941 13.5C1.01941 17.0899 3.92956 20 7.51941 20H14.5194C14.5926 20 14.6654 19.9988 14.738 19.9964ZM16.6913 17.721C19.0415 16.9522 20.9806 14.6815 20.9806 12C20.9806 8.68629 18.2943 6 14.9806 6C11.6669 6 8.98059 8.68629 8.98059 12H6.98059C6.98059 10.9391 7.1871 9.92643 7.56211 9H7.51941C5.03413 9 3.01941 11.0147 3.01941 13.5C3.01941 15.9853 5.03413 18 7.51941 18H14.5194C15.0691 18 15.9041 17.9014 16.6913 17.721Z" fill="currentColor" /></svg>

  <span>Cloud service</span><li>

</ul>

</div>
<div style="width:80%;height:63vh;overflow-y:scroll;" >
<div class="row" id="all-img-con" style="background:white;height:56vh;width:100%">
<div style='margin:auto;display:none;' id='img-loader'>
<div  class="lds-ripple"><div></div><div></div></div>
</div>
</div>
</div>
</div>
</div>


</div>

</div>


<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="height:8vh;background: #4a154b14 !important;">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link lnk-of-foot-nav" href="#" style="font-weight:700;">heptera|<sub>Studio</sub></a>
    </li>
    <li class="nav-item">
      <a class="nav-link lnk-of-foot-nav" href="../../template/" style="font-weight:600;">Template</a>
    </li>
    <li class="nav-item">
      <a class="nav-link lnk-of-foot-nav" href="#" style="font-weight:700;">More About</a>
    </li>
    
    
    
    
    
  </ul>
</nav>











<div  class="modal-2" data-modal="crt-new-dir-mdl" id="crt-new-dir-mdl-2" >
  <div class="modal-dialog modal-dialog-centered" style='max-width:70%;' role="document">
    <div class="modal-content" style="">

      
      
<div class="full-mdl-con-lrg">
    
        <div class="tw-rw-mdl-con" style="padding:0px;">

    <img src="https://res.cloudinary.com/heptera/image/upload/v1605083965/studio/Design_tools-pana_xkngeo.svg" style="width: 100%;margin-top: auto;height: 100%;">
    
</div>
        <div class="tw-rw-mdl-con">

<button class="close-btn-mdl" data-target-cls="crt-new-dir-mdl" style="width:fit-content;background: white;float: right;"><i class="fal fa-times-circle"></i></button>
    
    <div style="width:100%;text-align:center;overflow: scroll;">

<div class="" style="text-align:left">
<h2 style="color:black;font-size:20px">Create new Directory</h2>
<p class="mdl-lrg-notc-txt">Create Directory and fold your image with perfect choice Container</p>
<div style="padding:20px 3px;">

<label style="font-weight:450;color:black;letter-spacing:0.6px;">Create Directory</label>
        <input class="ip-by-def-dsg" id="dir_name_enter" name="nameofnewlist" type="text" style="" required="">

<div style="color:red;font-weight:500;" class="res"></div>

          
         
<div style="padding-top:40px;text-align:center">
<button class="btn-theme-dsg" id="create_dir_btn" type="submit" style="
    float: none;
"><span style="padding-right:10px;display:none;" id="crt_temp_load"><i class="fas fa-circle-notch fa-spin"></i></span><span>Create Directory</span><i class="fal fa-long-arrow-right" style="padding-left:10px;"></i></button>
</div>       

</div>
</div>
</div>
    
    

</div>
        
    
    
    </div>
      
    
    </div>
  </div>
</div>








<div  class="modal-2" data-modal="image_upload" id="image_upload-2" >
  <div class="modal-dialog modal-dialog-centered" style='max-width:70%;' role="document">
    <div class="modal-content" style="">

      
      
<div class="full-mdl-con-lrg">
    
        <div class="tw-rw-mdl-con" style="padding:0px;">

    <img src="https://res.cloudinary.com/heptera/image/upload/v1605084257/studio/Images-bro_krl1sz.svg" style="width: 100%;margin-top: auto;height: 100%;">
    
</div>
        <div class="tw-rw-mdl-con">

<button class="close-btn-mdl cls-with-ref" data-target-cls="image_upload" style="width:fit-content;background: white;float: right;"><i class="fal fa-times-circle"></i></button>
    
    <div style="width:100%;text-align:center;overflow: scroll;">

<div class="" style="text-align:left">
<h2 style="color:black;font-size:20px">Upload From Local Device</h2>
<p class="mdl-lrg-notc-txt">Provide Facility to Upload Image that you Store in local devices</p>
<div style="padding:20px 3px;">



<div class="con-of-sel-img-bd-md">
<form id="upload_img_form" action="https://img.sycista.com/upload_img.php">

<input id="dir_name_for_up" type="text" name="dir_name_up" value="19^c29jX2NvZGU=" style="display:none">



<div class="main-div-sel-img row">

<label class="file">

  <div class="con-of-img-sel">

    <div class="midd-sel-img" style="padding: 40px;">
    <i class="fal fa-layer-plus"></i>
</div>

<input class="in_img_data" type="file" name="pic[]" id="file" aria-label="File browser example" accept="image/*" multiple="" style="display:none;">
<span class="file-custom"></span>

</div>
</label></div>



</form></div>
      

</div>
</div>
</div>
    
    

</div>
        
    
    
    </div>
      
    
    </div>
  </div>
</div>






<div class="modal-2" data-modal="modal-del-dir" id="modal-del-dir-2">
  <article class="content-wrapper">
     
    
    

<div class="head-line-of-mdl">
    <h4>Are You Sure to Delete This Directory Permanently. </h4>

</div>

    <div class="content" style="
">
   <p>Once Delete this Directory than We not Responsible for your data lose policy.</p>
   </div>


<div class="btn-con-del-camp">

    <button class="btn-theme-dsg " id="del_fold_fin" style="">Yes,Delete Campign</button>
    
    <button class="btn-theme-dsg  close-btn-mdl" data-target-cls='modal-del-dir' style="background:white;color:#350835;border:1px solid #350835;">Cancel,Keep It Campign</button>

    
</div>


   
 
  </article>
</div>




























<div  class="modal-2" data-modal="link_img_url" id="link_img_url-2" >
  <div class="modal-dialog modal-dialog-centered" style='max-width:70%;' role="document">
    <div class="modal-content" style="">

      
      
<div class="full-mdl-con-lrg">
    
        <div class="tw-rw-mdl-con" style="padding:0px;">

    <img src="https://res.cloudinary.com/heptera/image/upload/v1605157572/studio/Online-bro_mbtkzs.svg" style="width: 100%;margin-top: auto;height: 100%;">
    
</div>
        <div class="tw-rw-mdl-con">

<button class="close-btn-mdl cls-with-ref" data-target-cls='link_img_url' style="width:fit-content;background: white;float: right;"><i class="fal fa-times-circle"></i></button>
    
    <div style="width:100%;text-align:center;overflow: scroll;">

<div class="" style="text-align:left">
<h2 style="color:black;font-size:20px">Link Image From Url</h2>
<p class="mdl-lrg-notc-txt">Save Image in Our System Using url. Eazy to save in folder.</p>
<div style="padding:20px 3px;">

<label style="font-weight:450;color:black;letter-spacing:0.6px;">Url Link</label>
        <input class="ip-by-def-dsg" id="link_frm_url"  name="nameofnewlist" type="text" style="" required="">

<div style="color:red;font-weight:500;" class="res"></div>

          
         
<div style="padding-top:40px;text-align:center">
<button class="btn-theme-dsg" id="link_frm_url_sub" type="submit" style="
    float: none;
"><span style="padding-right:10px;display:none;" id="crt_temp_load"><i class="fas fa-circle-notch fa-spin"></i></span><span>Link Image</span><i class="fal fa-long-arrow-right" style="padding-left:10px;"></i></button>
</div>       

</div>
</div>
</div>
    
    

</div>
        
    
    
    </div>
      
    
    </div>
  </div>
</div>






<div class="modal-2" data-modal="img_info_mdl" id="img_info_mdl-2">
  <div class="modal-dialog modal-dialog-centered"  role="document" style='min-width:fit-content;'>
    <div class="modal-content" style="">

<button class="close-btn-mdl" data-target-cls="img_info_mdl" style="width:fit-content;background: white;margin: 20px;margin-left: auto;"><i class="fal fa-times-circle"></i></button>
    <div class="mdl-of-info-data">

    <img id="img_thumb_shw" src="https://i0.wp.com/css-tricks.com/wp-content/uploads/2015/11/drag-drop-upload-1.gif?ssl=1" style="
    width: 200px;
">


<div class="main-txt-info-of-img">


    
<div class="thumb_data_val">


<div class="img_thumb_con">
    
        <div class="row">
            <div class="thumb_q" style="
">Created</div><div class="thumb_an" id="an_thumb_crt">12 dec 2018</div>
        </div> 
   
</div>

<div class="img_thumb_con">
        <div class="row">
            <div class="thumb_q" style="">Dimension</div><div class="thumb_an" id="an_thumb_dim">220*400</div>
        </div> 
    </div>


<div class="img_thumb_con">
        <div class="row">
            <div class="thumb_q" style="
">Created by</div><div class="thumb_an" id="an_thumb_crtnm">Ravi Gorasiya</div>
        </div> 
    </div>



<div class="img_thumb_con" style="">
        <div class="row">
            <div class="thumb_q" style="
">Size</div><div class="thumb_an" id="an_thumb_size">8kb</div>
        </div> 
    </div>
</div>


    

</div>

    

</div>
      

      
    
    </div>
  </div>
</div>





































<style>
.img_con_img{

position: absolute;
    margin: auto;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;


}

.img_con_info{

position: relative;
    height: 90vh;

}



a:not([href]):not([tabindex]) {
    color: inherit;
    text-decoration: none;
    color: #2c2c79c9;
}

.row{
margin-left:0px;
margin-right:0px;

}


.img_thumb_con {
    padding: 5px;
}


.thumb_q {
    font-weight: 500;
    width: 50%;
    text-align: left;
    font-size: 13px;

  }
.thumb_an{
font-weight:520;
color:#272b2b;
width:50%;
text-align:right;
font-size: 13px;

}

.thumb_data_val{
padding-top: 10px;
    padding-bottom: 10px;
    
}
</style>





<style type="text/css">

.full-mdl-con-lrg {
    width: 100%;
    height: 60vh;
    background: white;
border-radius: 10px;
  }

  .tw-rw-mdl-con {
    width: 49.5%;
    height: 60vh;
    display: inline-block;
    overflow: scroll;
    padding: 40px;
  }
  p.mdl-lrg-notc-txt {
    font-size: 13px;
    color: #565454;
    font-weight: 500;
    }


.mdl-of-info-data {
    width: 500px;
    text-align: center;
    padding: 40px;

  }

  .main-txt-info-of-img {
    padding: 40px 0px;

  }

  .err_of_ip_fld{
    background-color: #fff;
    outline: 0;
    border-color: #F44336;
    box-shadow: 0 0 0 3px #f4433659;

  }
</style>
























<style>
.modal-src-con{
width:100%;
background:white;
padding-bottom:10px;
border-bottom:1px solid #f2f2f2;
position:fixed;
padding-top:10px;
z-index:10000;
height:70px;
}


.con_of_fd_src {
    height: fit-content;
    width: 100%;
    padding-bottom: 20px;
    border-bottom: 1px solid #dedddc;


  }



.shadow-lg {
    width: fit-content;
    margin: auto;
    margin-top: 20px;
    border: 1px solid #611f69;

  }


</style>




<div class="modal fade" id="src_img_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" style='margin-top:0px;margin-bottom:0px;max-width:100%;'>
    <div class="modal-content" style='height:100vh;border-radius:0px;'>
      <div class="modal-header" style='border-bottom:1px solid #f2f2f2;'>
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div style='padding-top:0px;' class="modal-body">
<div class='modal-src-con'>
      <div class='shadow-lg bg-white rounded row' style='width:fit-content;margin:auto;'><div style='width:400px;border-radius: 1000px 0px 0px 1000px;'><input class='ip-src' id='ip-img-src2' placeholder='search Images' style=''></div><div class='src-btn' id='src-btn-2' style=''><button style='background:none;'><i class='far fa-search'></i></button></div></div>
      </div>

<div class='row' id='img_con_srch' style='margin-top:70px;padding-top:30px;'>





</div>






</div>
      
    </div>
  </div>
</div>









<div class="modal" id="err_mdl" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
     <div class='' id='mdl_err_txt'></div>
    </div>
  </div>
</div>







  <script src="./../assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  <script src="./../assets/js/argon-dashboard1.js"></script>
  <!--   Optional JS   -->
<script
  src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"
  integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30="
  crossorigin="anonymous"></script>  
 
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>
  
<script type="text/javascript">




$(function () {
    $('[data-toggle="tooltip"]').tooltip()
})


err_msg_data("test-error message display");



img_main_path='https://img.sycista.com/images/';


img_path_for_cors='http://3.12.107.213/images/'

id_name='';


fold_scop='';



append_txt_that_get_clck='';


dir_name_1="<?php echo $id;?>"+"^dW5kZWZpbmU=";




$(document).on('click','#upload_frm_local',function(){



modalEvent(this);

});






$(document).on("change",".in_img_data",function(){

  

append_load_in_all_btn(".midd-sel-img");

val=$("#upload_img_form");

$('#upload_img_form').each(function(){
  $.ajax({
    
    //Getting the url of the uploadphp from action attr of form 
    //this means currently selected element which is our form 
    url: $(this).attr('action'),
    
    //For file upload we use post request
    type: "POST",
    
    //Creating data from form 
    data: new FormData(this),
    
    //Setting these to false because we are sending a multipart request
    contentType: false,
    cache: false,
    processData: false,
    success: function(data){
console.log(data);

$(".con-of-img-sel").remove();


$(".main-div-sel-img").append("<div class='img-con-pre'  id='"+data+"'><img class='img-pre-tg-img' src='https://img.sycista.com/images/"+data+"' /></div><label class='file'><div class='con-of-img-sel'><div class='midd-sel-img' style='padding: 40px;'><i class='fal fa-layer-plus'></i></div><input class='in_img_data' type='file' name='pic[]' id='file' aria-label='File browser example' accept='image/*' multiple='' style='display:none;'><span class='file-custom'></span></label>");


    }
  
  });



});

});





function append_load_in_all_btn(selector){

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



















$(document).on("click","#cld_img_get",function(){


up_btn_disabled();

dir_name_1= "<?php echo $id;?>"+"^Y2xvdWRfY29kZQ==";


rem_opt_btn();
$("#all-img-con").empty();



list_log_act("cld_img_get");



$("#all-img-con").html('<div class="con_of_fd_src"><div class="shadow-lg bg-white rounded row"> <button class="btn-without-clr btn_hover_clr"><i class="fal fa-cloud-download"></i>Connect Cloud</button> </div></div>');




append_img_loader();

fold_scop='src_nw';




get_img_of_dir();







})












$(document).on("click",".down_btn_img_dir",function(){

 window.open(img_main_path+op[0], '_blank');




})























$(document).on("click","#soc_img",function(){


up_btn_disabled()



$(".delet_btn").css("display","none");
    $(".show_edt_btn").css("display","none");
    $("#all-img-con").empty();
append_img_loader();


list_log_act("soc_img");


$.ajax({
    url : 'ajaxfile/getdirimg.php',
    type: 'POST',
    data : {'dir_name':'<?php echo $id;?>'+"^c29jX2NvZGU="}
  }).done(function(response){ //
    $("#all-img-con").empty();
    $("#dir_name_for_up").val(dir_name_1);
    var get_res_img=JSON.parse(response);

       $("#folder_open").html(atob(dir_name_1.split("^")[1]));
        $("#upload_img_dir").html(atob(dir_name_1.split("^")[1]));

 if(response==0){

  conole.log("ravi");

$("#all-img-con").append("<div class='not-fd-data'><img src='https://res.cloudinary.com/heptera/image/upload/v1586842446/smart-farm_kah6xi.png' height='64'><div class='txt-not-fd'>Connect Your heptera |<sub>studio</sub> account with facebook and we directly get image from Your fb account</div><div class='shadow-lg bg-white rounded row' style='box-shadow:0 0 3rem rgba(136, 152, 170, 0.5)  !important'></div><a href='./facebook'><button class='btn_hover_clr' style='float:none;border: #840e69;'>Link Facebook Account</button></a></div>");

   }else{

 for(i in get_res_img){
        $("#all-img-con").append(getconimg(get_res_img[i]));

init_img_url();
}
   }




    $("#all-img-con").css("display","");



});


  });



$(document).on("click","#customtbl_img",function(){


up_btn_disabled();

rem_opt_btn();
$("#all-img-con").empty();


list_log_act("customtbl_img");



$("#all-img-con").html("<div class='con_of_fd_src'><div class='shadow-lg bg-white rounded row'><div style='width:400px;border-radius: 1000px 0px 0px 1000px;'><input class='ip-src' id='ip-img-src' placeholder='search Images' style=''></div><div class='src-btn' id='src-btn' data-toggle='modal' data-target='#src_img_modal' style=''><button style='background:none;'><i class='far fa-search'></i></button></div></div></div>");   
  



append_img_loader();


dir_name_1='<?php echo $id;?>'+"^Y3VzdHVtaXplZA==";

fold_scop='src_nw';

get_img_of_dir();






});


$(document).on("click","#src-btn",function(){


var img_src_name=$("#ip-img-src").val();

$("#img_con_srch").empty();
get_img_data_app(img_src_name,1);

get_img_data_app(img_src_name,2);
});





$(document).on("click","#src-btn-2",function(){



img_src_name=$("#ip-img-src2").val();

$("#img_con_srch").empty();
get_img_data_app(img_src_name,1);

get_img_data_app(img_src_name,2);
});
















function get_img_data_app(img_src_name,page_data){


$.get( "https://api.unsplash.com/search/photos?orientation=landscape&query="+img_src_name+"&client_id=Ek9RlP8cGxAay92PjI7VJy_1OnOwq-EHT5YxahMZfqQ&page="+page_data, function( data ) {


var json_res_src=JSON.stringify(data);

var get_res_img_srch=JSON.parse(json_res_src);

console.log(get_res_img_srch.results[0]);
page_count_img=get_res_img_srch.total_pages;

for(i in get_res_img_srch.results){




$("#img_con_srch").append("<div class='cont-img-data'><img src='"+get_res_img_srch.results[i].urls.raw+"&w=200&h=200' alt='Avatar' class='image-data-kl'><div class='overlay-2' ><div class='' style='width:100%;float:right;'><div class='down_con down_con_api' id='"+get_res_img_srch.results[i].urls.raw+"&w=200&h=200' >saved in <img height='13' src='https://res.cloudinary.com/heptera/image/upload/v1605159176/studio/Online-bro_xp00dd.svg'></div></div></div></div>");


}



data='{}';
});



}





$(document).on("click",".down_con_api",function(){

img_url=$(this).attr("id");


append_load_in_all_btn("#"+img_url);


stc_url_from_link(img_url);



append_txt_of_lds("#"+img_url);





});
















function list_log_act(id_of_act){

$(".list-log-act").map(function(){

$(this).attr("class","list-log");

});

$("#"+id_of_act).attr("class","list-log-act");

}







function get_con_of_fold(split_dir_name_para){
var data_for_id=split_dir_name_para;
    var dir_name_on=split_dir_name_para.split("^");
   
var str_of_fold_data="<div class='getimg fold_con' id='"+data_for_id+"' style=''><img src='https://res.cloudinary.com/heptera/image/upload/v1585893941/folder_2_ipebck.png' height='60'><div class='fold_name' style=''>"+atob(dir_name_on[1])+"</div></div>";


return str_of_fold_data;
}







$(document).on("click","#crw_fold_data",function(){

$("#folder_open").empty();
$(".delet_btn").css("display","none");
    $(".show_edt_btn").css("display","none");
    $("#all-img-con").empty();

append_img_loader();


list_log_act("crw_fold_data");



$.ajax({
                url : 'ajaxfile/get_dir_name.php?flg=1',
                type: 'POST',
                data : {'img_name':"ig"}
}).done(function(response){ //

  $("#all-img-con").empty();
if(response=='0'){

$("#all-img-con").append("<div class='not-fd-data'><img src='https://image.flaticon.com/icons/svg/2103/2103633.svg' height='64'><div class='txt-not-fd'>you not added any site till now. please connect your site from below button.</div><button class='btn_hover_clr' data-toggle='modal' data-target='#image_upload' style='float:none;border: #840e69;'>Link Site</button></div>");

}else{
    
var datajson=response;
var data_dir=JSON.parse(datajson);
for(i in data_dir){
    var split_dir_name=data_dir[i].dir;
    
    
    $("#all-img-con").append(get_con_of_fold(split_dir_name));
}
}
});






});

















$(document).on("click","#all_fold_data",function(){

$("#folder_open").empty();


rem_opt_btn();

$("#all-img-con").empty();



list_log_act("all_fold_data");


append_img_loader();



open_all_dir_tab();





});


function open_all_dir_tab(){




$.get( "ajaxfile/get_dir_name.php?flg=0", function( datajson ) {
  




if(datajson==0){


$("#all-img-con").html('<div class="not-fd-data"><img src="https://image.freepik.com/free-vector/folder-concept-illustration_114360-2946.jpg" height="200"><div class="txt-not-fd">No folder Present In Your Library.</div><button class="btn_hover_clr" data-toggle="modal" data-target="#myModal" style="float:none;border: #840e69;">Create Folder</button></div>');


}else{

var data_dir=JSON.parse(datajson);

$("#all-img-con").empty();

for(i in data_dir){
    var split_dir_name=data_dir[i].dir;
    
    
    $("#all-img-con").append(get_con_of_fold(split_dir_name));

}

}

  });



}




function rem_opt_btn(){


$(".delet_btn").css("display","none");
    $(".show_edt_btn").css("display","none");
    

}



$(document).on("click",".copy_con_all",function(){
 var $temp = $("<input>");
$("body").append($temp);
var copy_text_data=img_main_path+op[0];
$temp.val(copy_text_data).select();



document.execCommand("copy");

$temp.remove();


err_msg_data("Copy Link Successfull");

});








$(document).on("click","#info_img_href",function(){


name_img=op[0];


$("#img_thumb_shw").attr("src",img_main_path+name_img);


modalEvent(this);


init_img_info_mdl();


});



function init_img_info_mdl(){




$.ajax({
                url : 'ajaxfile/get_img_data.php',
                type: 'POST',
                data : {'img_name':name_img}
        }).done(function(response){ //
    
    var json_data_thumb=JSON.parse(response);
    $("#an_thumb_name").html(json_data_thumb.org_name);
        $("#an_thumb_crt").html("12 dec 2078");
        $("#an_thumb_dim").html(json_data_thumb.width+"*"+json_data_thumb.height);
$("#an_thumb_size").html(json_data_thumb.size);       
$("#an_thumb_crtnm").html("ravi Gorasiya");

        });


}



$(document).on("click","#delet_fold",function(){
del_fold=dir_name_1;


del_fold_name_shw=del_fold.split("^")[1];

console.log(del_fold_name_shw=="dW5kZWZpbmU=");

if(del_fold_name_shw!="dW5kZWZpbmU="){


modalEvent(this);

}

});




$(document).on("click","#del_fold_fin",function(){


append_load_in_all_btn("#del_fold_fin");


$.ajax({
  type: "GET",
  url: "https://img.sycista.com/del_fold.php",
  data: {fold_old_name:dir_name_1}
}).done(function(response1) {
append_txt_of_lds("#del_fold_fin");



        if(response1==1){

          window.location.href='http://localhost/html/dash/main/studio-serve/';


err_msg_data("Delete Directory Successfull");

        }else{

err_msg_data("Something Went Wrong");

        }
   
    $("#del_fold").css("display","none");
   
});

});








$(document).on( 'click', '#create_dir_btn', function(){
    var name_dir=$("#dir_name_enter").val();
    if(name_dir.length>0){


append_load_in_all_btn("#create_dir_btn");


setTimeout(function(){ 
$.ajax({
    url : 'ajaxfile/addnewdir.php',
    type: 'POST',
    data : {'add_dir_name':name_dir}
  }).done(function(response){ //
    $("#dir_crt_res").empty();
    if(response==0){



      intit_ip_fld_at_err_rem("#dir_name_enter");
    
    init_dir_name_in_dp();

cls_mdl_of_act("#crt-new-dir-mdl-2");

append_txt_of_lds("#create_dir_btn");
$("#dir_name_enter").val("");

    
    }else{
        
intit_ip_fld_at_err("#dir_name_enter");
        append_txt_of_lds("#create_dir_btn");

        err_msg_data("Folder Already Exist");
    }
    
    
  });
},2000);

}
});



$(document).on( 'click', '.overlay', function(){

   
   
   $(this).css("opacity","0.4");


op.push(this.id);


 display_del(count_sel_img);
    display_edt_opt(count_sel_img);

$(this).addClass("select");

});


 
$(document).on( 'click', '.select', function(){
    

    $(this).css("opacity","0");
    op.splice(op.indexOf(this.id), 1 );
    op.splice(op.indexOf(this.id), 1 );
    
    $(this).removeClass("select");

    display_del(count_sel_img);
display_edt_opt(count_sel_img);
    
});

function display_del(num_img_sel){
    if(op.length==0){
        $(".delet_btn").css("display","none");
    }else{
        $(".delet_btn").css("display","inline-block");
    }
}
function display_edt_opt(sel_img_edt){
    if(op.length==1){
        $(".show_edt_btn").css("display","inline-block");
    }else{
        $(".show_edt_btn").css("display","none");
    }
}

$(document).on("click",".edit_btn",function(){

const ImageEditor = new FilerobotImageEditor();
b = new Date();
  ImageEditor.open(img_path_for_cors+op[0]+'?'+b.getTime());
  
$(".sc-kEYyzF").html("<a href='#' class='savelink' id='img_edt_sub'  style='' >Save Changes</a>");

});

$(document).on("click","#img_edt_sub",function(){

var can = document.getElementById('scaleflex-image-edit-box');
var ctx = can.getContext('2d');


var dataURL = can.toDataURL();
    
   
    
   $.ajax({
  type: "GET",
  url: "https://img.sycista.com/script.php",
  contentType: "application/json",
  proccessData: false,
  data: { 
     imgname:op[0],
     imgBase64: dataURL
  },
	  success: function(data) {
console.log(data);

$("#filerobot-image-editor").next().remove();
$("#filerobot-image-editor").remove();

       


init_suc_stat("sucessfully saved image");

$("#all-img-con").empty();

append_img_loader();
 

get_img_of_dir();


        // show results of successfull request
    },
    error: function(jq,status,message) {


console.log(message);
$("#filerobot-image-editor").next().remove();
$("#filerobot-image-editor").remove();

init_suc_stat("sucessfully saved image");

$("#all-img-con").empty();

append_img_loader();
 

get_img_of_dir();


        
    }





})

});


function init_suc_stat(txt_suc){

 $("#err_mdl").modal('show');

 $("#mdl_err_txt").html(txt_suc);

 $("#mdl_err_txt").addClass('mdl_stat_suc');

}


function getarr(){
    $(".res").html(op);
}

$("#copy_link_img").click(function() {

  






});







$(document).on( 'click', '#link_frm_url_sub', function(){


img_url=$("#link_frm_url").val();

console.log($("#link_frm_url").val());
    

stc_url_from_link(img_url);

});
  
      

function stc_url_from_link(link){





$.ajax({
    url : 'http://img.sycista.com/stc_img_url.php',
    type: 'GET',
    data : 'dir_name='+dir_name_1+'&img_url='+link
  }).done(function(response){ //


console.log(response);


if(response==1){

$('#link_img_url').modal('hide');


$('#src_img_modal').modal('hide');



append_img_loader();


get_img_of_dir();

}else{

  

$("#link_img_res_err").html("please Try after some time");

}
  });




}


$(document).ready(function(){



get_all_url_data_for_act();




init_dir_name_in_dp();



append_img_loader();
 

get_img_of_dir();



})



function get_all_url_data_for_act(){


curr_page=window.location.href;

if(curr_page.search("#")>=0){

mdl_data=curr_page.split("#")[1];

if(mdl_data.search("-")>=0){

all_usd_dt=mdl_data.split('-');



if(all_usd_dt[0]=='fld'){


dir_name_1=all_usd_dt[1];


 

get_img_of_dir();




}else if(all_usd_dt[0]=='mdl'){



}
}

}

}



function init_mdl_if_any_query(){


$("#"+mdl_data+"-2").addClass('open');


}








function get_img_of_dir(src){



console.log(op);

op=[];

$.ajax({
    url : 'ajaxfile/getdirimg.php',
    type: 'POST',
    data : {'dir_name':dir_name_1}
  }).done(function(response){ //



   
    $("#dir_name_for_up").val(dir_name_1);
    var get_res_img=JSON.parse(response);


    
    $("#folder_open").html(atob(dir_name_1.split("^")[1]));
        $("#upload_img_dir").html(atob(dir_name_1.split("^")[1]));
    

       $("#img-loader").remove();
     


    if(response==0){



if(fold_scop=='src_nw'){




}else{

        not_fd_data();


      }
    }else{




if(fold_scop=='src_nw'){




}else{

        $("#all-img-con").empty();


      }






for(i in get_res_img){
        $("#all-img-con").append(getconimg(get_res_img[i]));
        
init_img_url();        
    }


    }
    $("#all-img-con").css("display","");
  });


}




function init_dir_name_in_dp(){

$("#dir_data").empty();

$.get( "ajaxfile/get_dir_name.php?flg=0", function( datajson ) {
  

console.log(datajson);

if(datajson==0){

$("#dir_data").html('<div class="not-fd-data"><img src="https://res.cloudinary.com/heptera/image/upload/v1599539834/studio/test_dxk6he.svg" height="64" style=" padding: 10px; "><br><button class="btn_hover_clr" data-toggle="modal" data-target="#myModal" style="float:none;border: #840e69;">Create Folder</button></div>');


}else{


var data_dir=JSON.parse(datajson);

for(i in data_dir){
    var split_dir_name=data_dir[i].dir;
    var data_for_id="'"+split_dir_name+"'";
    var dir_name_on=split_dir_name.split("^");
    
    $("#dir_data").append("<div id="+data_for_id+" class='getimg' data-flg-ext='"+data_dir[i].extra+"'><a  href='#'><img src='https://res.cloudinary.com/heptera/image/upload/v1604420625/icon-svg/align-left_nwl9zn.svg' height='20'/><span style='padding-left:10px;'>"+atob(dir_name_on[1])+"</span></a><span class='' style='color:black;padding-left:20px;float:right;'>"+data_dir[i].count+" files</span></div>");
}

}


});





}












return_dir='';
function set_img_session(name_of_dir){
 

console.log(name_of_dir);
}





function append_img_loader(){



$("#all-img-con").append("<div style='margin:auto;' id='img-loader'> <div class='lds-ripple'><div></div><div></div></div> </div>");


}






function not_fd_data(){


$("#all-img-con").html("<div class='not-fd-data'  ><img src='https://res.cloudinary.com/heptera/image/upload/v1599988908/studio/img_skzswj.jpg' height='200'/><div class='txt-not-fd'>This Directory Not Contains Any Images so, if You Wish To add click Below.</div><button class='btn_hover_clr' data-toggle='modal' data-target='#image_upload' style='float:none;' >upload Images</button></div>");


}



$(document).on( 'click', '.getimg', function(){
   


    $(".delet_btn").css("display","none");
    $(".show_edt_btn").css("display","none");
    $("#all-img-con").empty();
    op=[];
    count_sel_img=0;

dir_name_1=$(this).attr('id');

$("#all-img-con").empty();

append_img_loader();



get_img_of_dir();


up_btn_enable();


setTimeout(function(){ window.location.href='http://localhost/html/dash/main/studio-serve/#fld-'+dir_name_1; }, 2000);




 });



function init_img_url(){



var img_dt=$( "#all-img-con" ).find("#new_img_con").children("img").attr("id");

img_id_db=img_dt.substr(0, img_dt.length - 3);

$( "#all-img-con" ).find("#new_img_con").children("img").attr("src","http://img.sycista.com/images/"+img_id_db+"?"+d.getTime());

$( "#all-img-con" ).find("#new_img_con").attr("id","none");



}


function getconimg(url_img){
    d = new Date();
var con_img="<div class='img-con' id='new_img_con'><img class='imag-cls' src='https://image.flaticon.com/icons/svg/132/132779.svg' id='"+url_img+"img'  alt='Avatar' class='image'><div class='overlay'  id='"+url_img+"' ><div class='text'><i class='far fa-minus-square' style='font-size:30px;color:black;'></i></div></div></div>";








return con_img;

}










$(document).on( 'click', '#sub_del_img', function(){
     
$("#all-img-con").empty();

append_img_loader();
     
setTimeout(function(){ 
$.ajax({
    url : 'https://img.sycista.com/delimg.php',
    type: 'POST',
    data : {'del_array':op}
  }).done(function(response){ //
    


init_dir_name_in_dp();


get_img_of_dir();


$("#sub_del_img").html('<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M17 5V4C17 2.89543 16.1046 2 15 2H9C7.89543 2 7 2.89543 7 4V5H4C3.44772 5 3 5.44772 3 6C3 6.55228 3.44772 7 4 7H5V18C5 19.6569 6.34315 21 8 21H16C17.6569 21 19 19.6569 19 18V7H20C20.5523 7 21 6.55228 21 6C21 5.44772 20.5523 5 20 5H17ZM15 4H9V5H15V4ZM17 7H7V18C7 18.5523 7.44772 19 8 19H16C16.5523 19 17 18.5523 17 18V7Z" fill="currentColor"></path><path d="M9 9H11V17H9V9Z" fill="currentColor"></path><path d="M13 9H15V17H13V9Z" fill="currentColor"></path></svg>');



    
  });
},2000);


});



$(document).on('hover','.list-log-act',function(){

console.log('ravi');

})









function up_btn_disabled(){



$("[dis-target|='allow']").map(function(){

$(this).prop('disabled', true);

});

}


function up_btn_enable(){



$("[dis-target|='allow']").map(function(){

$(this).prop('disabled', false);

});


}




$(document).on('click','#add_folder_con',function(){


console.log(this)


modalEvent(this);


})


$(document).on('click','#btn-open-mdl-url',function(){


modalEvent(this);


})




function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');

    console.log(trigger)
    const modal = document.querySelector(`[data-modal=${trigger}]`);
    const contentWrapper = modal.querySelector('.content-wrapper');
    
    
    modal.classList.toggle('open');
  
}


$(document).on('click','.close-btn-mdl',function(){


sel_id=$(this).attr('data-target-cls')+"-2";

$("#"+sel_id).removeClass("open");

})









function err_msg_data(message){


$("#con-of-err-msg").html(message);

$("#err_msg_dt_trg").css('display','inline-block');



setTimeout(
    function() {


      $("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');
      
    }, 5000);


}


$(document).on('click','#cncl-err-msg',function(){


$("#con-of-err-msg").empty();
$("#err_msg_dt_trg").css('display','none');

})



$(document).on('click','.cls-with-ref',function(){



location.reload();


})




function append_load_in_all_btn(selector){




append_txt_that_get_clck=$(selector).html();

$(selector).prop("disabled",true);

$(selector).html('<div class="cp-spinner cp-round"></div>');

}



function append_txt_of_lds(selector){

$(selector).prop("disabled",false);

$(selector).html(append_txt_that_get_clck);


}


function intit_ip_fld_at_err(selector){

$(selector).addClass("err_of_ip_fld");


}


function intit_ip_fld_at_err_rem(selector){


$(selector).removeClass("err_of_ip_fld");

}


function cls_mdl_of_act(selector){



$(selector).removeClass("open");

}
</script>


</html>







