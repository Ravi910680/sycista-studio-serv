<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdn.scaleflex.it/plugins/filerobot-image-editor/3/filerobot-image-editor.min.js"/></script>

<a href="#" onclick="ravi()">ravi</a>
<div id="res" style="width:100%;height:20px;z-index:1"></div>
<body>
</body>
<style>
.sc-kEYyzF{
    text-align:right;
    padding:20px;
    font-size:15px;
}
.savelink:hover{
color:blue;
}
</style>
<script>
function ravi(){

  
  

  

  const ImageEditor = new FilerobotImageEditor();

  ImageEditor.open('https://scaleflex.airstore.io/demo/stephen-walker-unsplash.jpg');
  
$(".sc-kEYyzF").html("<a href='#' class='savelink'  style='text-align:center;color:white;text-decoration:none;font-weight:200;' onclick='sub()'>Save Changes</a>");

     
    

}
function sub(){
    var can = document.getElementById('scaleflex-image-edit-box');
var ctx = can.getContext('2d');


var dataURL = can.toDataURL();
    
   $("#res").html("ravi");
    
   $.ajax({
  type: "POST",
  url: "ajxfile/script.php",
  data: { 
     
     imgBase64: dataURL
  }
}).done(function(o) {
    $(".res").html(o);
  console.log('saved'); 
});
}

</script>