<!DOCTYPE html>
<html style="height:100%;width:100%">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://uicdn.toast.com/tui-color-picker/v2.2.0/tui-color-picker.css">
        <link rel="stylesheet" href="https://uicdn.toast.com/tui-image-editor/v3.3.0/tui-image-editor.css">
    </head>
    <body style="height:100%;width:100%">
        <div id="tui-image-editor-container"></div>

        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/1.6.7/fabric.js"></script>
        <script type="text/javascript" src="https://uicdn.toast.com/tui.code-snippet/v1.5.0/tui-code-snippet.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.3/FileSaver.min.js"></script>
        <script type="text/javascript" src="https://uicdn.toast.com/tui-color-picker/v2.2.0/tui-color-picker.js"></script>
        <script type="text/javascript" src="https://uicdn.toast.com/tui-image-editor/v3.3.0/tui-image-editor.js"></script>
        

        <script>
         // Create an instance of the tui imageEditor, loading a blank image
         
         var imageEditor = new tui.ImageEditor('#tui-image-editor-container', {
             includeUI: {
                 loadImage: {
                     path: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
                     name: 'Blank'
                 },
                 
                 menuBarPosition: 'bottom'
             },
             cssMaxWidth: 700,
             cssMaxHeight: 700
         });

         // Patch the loadImageFromURL of our tui imageEditor instance:
         imageEditor.loadImageFromURL = (function() {
             var cached_function = imageEditor.loadImageFromURL;
             function waitUntilImageEditorIsUnlocked(imageEditor) {
                 return new Promise((resolve,reject)=>{
                     const interval = setInterval(()=>{
                         if (!imageEditor._invoker._isLocked) {
                             clearInterval(interval);
                             resolve();
                         }
                     }, 100);
                 })
             }
             return function() {
                 return waitUntilImageEditorIsUnlocked(imageEditor).then(()=>cached_function.apply(this, arguments));
             };
         })();

        
        </script>
    </body>
</html>
